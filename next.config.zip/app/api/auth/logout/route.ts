import { NextResponse } from "next/server";
import { COOKIE_NAME } from "@/lib/auth";
export async function POST() { const r=NextResponse.json({ok:true}); r.cookies.set(COOKIE_NAME,"",{path:"/",maxAge:0}); return r; }
